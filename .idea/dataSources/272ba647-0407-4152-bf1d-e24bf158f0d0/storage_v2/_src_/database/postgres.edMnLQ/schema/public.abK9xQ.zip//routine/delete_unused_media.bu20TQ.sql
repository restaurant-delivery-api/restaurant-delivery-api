create function delete_unused_media() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE
    FROM media
    WHERE id = OLD.media_id
      AND id <> 172;
    RETURN OLD;
END;
$$;

alter function delete_unused_media() owner to postgres;

