create procedure import_csv(IN table_name character varying, IN pth character varying, IN delim character varying)
    language plpgsql
as
$$
BEGIN
    EXECUTE format('TRUNCATE TABLE bd_hotel.%I CASCADE', table_name);
    EXECUTE format( 'copy bd_hotel.%I FROM %L WITH DELIMITER %L CSV HEADER', table_name, pth, delim);
END;
$$;

alter procedure import_csv(varchar, varchar, varchar) owner to postgres;

