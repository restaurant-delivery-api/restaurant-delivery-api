create function check_and_delete_media() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM media
    WHERE id = OLD.media_id;
    RETURN OLD;
END;
$$;

alter function check_and_delete_media() owner to postgres;

