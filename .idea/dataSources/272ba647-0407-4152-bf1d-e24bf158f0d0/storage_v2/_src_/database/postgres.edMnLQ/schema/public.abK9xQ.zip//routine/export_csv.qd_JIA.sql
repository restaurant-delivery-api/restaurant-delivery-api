create procedure export_csv(IN table_name character varying, IN pth character varying, IN delim character varying)
    language plpgsql
as
$$
BEGIN
    EXECUTE format('COPY %I TO %L DELIMITER %L CSV HEADER', table_name, pth, delim);
END;
$$;

alter procedure export_csv(varchar, varchar, varchar) owner to postgres;

