create function delete_client_duty() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE bd_hotel.clients
    SET duty = COALESCE(duty, 0) - (SELECT price
                                    FROM bd_hotel.services
                                    WHERE service_id = OLD.service_id)
    WHERE client_id = OLD.person_id;

    RETURN OLD;
END;
$$;

alter function delete_client_duty() owner to postgres;

