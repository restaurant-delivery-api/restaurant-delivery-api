create procedure exporttable(IN table_name character varying, IN name_file character varying, IN deli character)
    language plpgsql
as
$$
BEGIN
    EXECUTE FORMAT('COPY %I TO %L DELIMITER %L CSV HEADER', table_name, name_file, deli);
END;
$$;

alter procedure exporttable(varchar, varchar, char) owner to postgres;

