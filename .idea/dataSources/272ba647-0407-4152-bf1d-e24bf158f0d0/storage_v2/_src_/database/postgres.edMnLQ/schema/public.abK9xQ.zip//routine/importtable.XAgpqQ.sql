create procedure importtable(IN table_name character varying, IN path_to_file character varying, IN deli character)
    language plpgsql
as
$$
BEGIN
    EXECUTE FORMAT('COPY %I FROM %L DELIMITER %L CSV HEADER', table_name, path_to_file, deli);
END;
$$;

alter procedure importtable(varchar, varchar, char) owner to postgres;

