create function delete_collections_distribution() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM collections_distribution
    WHERE collection_id = OLD.id;
    RETURN OLD;
END;
$$;

alter function delete_collections_distribution() owner to postgres;

