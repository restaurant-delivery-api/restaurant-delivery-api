create function update_client_duty() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE bd_hotel.clients
    SET duty = COALESCE(duty, 0) + (SELECT price
                                    FROM bd_hotel.services
                                    WHERE service_id = NEW.service_id)
    WHERE client_id = NEW.person_id;

    RETURN NEW;
END;
$$;

alter function update_client_duty() owner to postgres;

