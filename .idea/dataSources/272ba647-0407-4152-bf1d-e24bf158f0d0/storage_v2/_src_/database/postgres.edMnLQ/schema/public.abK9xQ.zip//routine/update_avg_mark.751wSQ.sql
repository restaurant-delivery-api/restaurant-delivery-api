create function update_avg_mark() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT 1 FROM  litera_vibe.avg_marks WHERE book_id = NEW.book_id) THEN
        UPDATE  litera_vibe.avg_marks
        SET avg_mark = (SELECT AVG(mark) FROM marks WHERE book_id = NEW.book_id)
        WHERE book_id = NEW.book_id;
    ELSE
        INSERT INTO  litera_vibe.avg_marks (book_id, avg_mark, quantity)
        VALUES (NEW.book_id, NEW.mark, 1);
    END IF;

    RETURN NEW;
END;
$$;

alter function update_avg_mark() owner to postgres;

