create function get_occupied_rooms()
    returns TABLE(room_id bigint, room_reservation_id bigint, person_id bigint, occupied_from date, occupied_to date)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        WITH reserved_ids AS (SELECT reserve_id, rent_from AS occupied_from, rent_to AS occupied_to
                              FROM bd_hotel.reservations
                              WHERE rent_to >= current_date
                                AND rent_from <= current_date)
        SELECT rr.room_id, rr.reservation_id AS room_reservation_id, rr.person_id, ri.occupied_from, ri.occupied_to
        FROM bd_hotel.room_reservations rr
                 JOIN reserved_ids ri ON rr.reservation_id = ri.reserve_id;
END;
$$;

alter function get_occupied_rooms() owner to postgres;

