create function get_available_rooms()
    returns TABLE(room_id bigint, number bigint, room_type_id bigint, floor smallint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT r.room_id, r.number, r.room_type_id, r.floor
        FROM bd_hotel.rooms r
                 LEFT JOIN get_occupied_rooms() rr ON r.room_id = rr.room_id
        WHERE rr.room_id IS NULL;
END;
$$;

alter function get_available_rooms() owner to postgres;

