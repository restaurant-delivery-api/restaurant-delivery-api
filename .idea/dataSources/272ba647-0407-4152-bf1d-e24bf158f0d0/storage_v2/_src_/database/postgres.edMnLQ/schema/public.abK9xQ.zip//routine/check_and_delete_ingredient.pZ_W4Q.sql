create function check_and_delete_ingredient() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM ingredients
    WHERE id = OLD.ingredient_id
      AND NOT EXISTS (
            SELECT 1 FROM ingredients_distribution
            WHERE ingredient_id = OLD.ingredient_id
        );
    RETURN OLD;
END;
$$;

alter function check_and_delete_ingredient() owner to postgres;

