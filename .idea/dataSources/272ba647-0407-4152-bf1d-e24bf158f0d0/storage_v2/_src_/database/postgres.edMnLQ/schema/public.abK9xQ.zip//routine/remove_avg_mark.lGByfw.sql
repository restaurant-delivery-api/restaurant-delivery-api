create function remove_avg_mark() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE  litera_vibe.avg_marks
    SET avg_mark = (SELECT AVG(mark) FROM  litera_vibe.marks WHERE book_id = OLD.book_id),
        quantity = quantity - 1
    WHERE book_id = OLD.book_id;

    RETURN OLD;
END;
$$;

alter function remove_avg_mark() owner to postgres;

