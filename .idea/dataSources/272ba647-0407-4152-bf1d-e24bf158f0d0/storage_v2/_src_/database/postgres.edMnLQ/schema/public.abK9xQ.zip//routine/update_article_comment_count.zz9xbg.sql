create function update_article_comment_count() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE linacy.articles
    SET comment_count = comment_count + 1
    WHERE id = NEW.article_id;
    RETURN NEW;
END;
$$;

alter function update_article_comment_count() owner to postgres;

